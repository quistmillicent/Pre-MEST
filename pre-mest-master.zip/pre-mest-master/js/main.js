console.log("helloooo .....")

let b = 78

console.log(b);